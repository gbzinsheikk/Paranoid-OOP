#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "duarkanoid.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    mArkanoid = new DuArkanoid(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
