#ifndef DUUTIL_H
#define DUUTIL_H


class DuUtil
{
public:
    static int abs(int value);
};

#endif // DUUTIL_H
