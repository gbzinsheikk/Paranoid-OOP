#include "duutil.h"

int DuUtil::abs(int value)
{
    return value < 0 ? -value : value;
}
